import unittest

# TODO: June 22, 2020: Add real test cases
class TestExample(unittest.TestCase):

    def test_working(self):
        self.assertEqual(True, True, 'True should be equals True')


if __name__ == "__main__":
    unittest.main()
